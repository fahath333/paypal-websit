var bttn = "Welcome to our Website"
alert(bttn);
function bttn(bttn) {
    alert("upgrade soon");
    
}
